﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WhileDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //While-Demo
            //Take input of any number and display its mathematical table

            int i, n, p;

            Console.Write("Enter any number:");
            n=int.Parse(Console.ReadLine());
            i = 1;

            while (i<=10)
            {
                //calculate product
                p = n * i;
                //Console.WriteLine(n + " x " + i +" = " + p);
                //Console.WriteLine("{0} x {1} = {2}", n, i, p);
                Console.WriteLine($"{n} x {i} = {p}");
                
                i++; //OR i=i+1 OR i+=1
            }
        }
    }
}
