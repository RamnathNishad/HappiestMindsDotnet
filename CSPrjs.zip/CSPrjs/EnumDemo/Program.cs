﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnumDemo
{
    enum MenuChoice
    {
        Add=1,
        Subtract,
        Multiply,
        Divide,
        Exit=0
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            int choice;

            do
            {
                int n1, n2, result;
                Console.Write("Enter n1:");
                n1 = int.Parse(Console.ReadLine());
                Console.Write("Enter n2:");
                n2 = int.Parse(Console.ReadLine());


                Console.WriteLine("1.Add");
                Console.WriteLine("2.Subtract");
                Console.WriteLine("3.Multiply");
                Console.WriteLine("4.Divide");
                Console.WriteLine("0.Exit");

                Console.Write("Enter choice:");
                choice = int.Parse(Console.ReadLine());

                switch (choice)
                {
                    case (int)MenuChoice.Add:
                        //Add the numbers
                        result = n1 + n2;
                        Console.WriteLine("Sum:" + result);
                        break;
                    case (int)MenuChoice.Subtract:
                        //Subtract the numbers
                        result = n1 - n2;
                        Console.WriteLine("Difference:" + result);
                        break;
                    case (int)MenuChoice.Multiply:
                        //Multiply the numbers
                        result = n1 * n2;
                        Console.WriteLine("Multiplication:" + result);
                        break;
                    case (int)MenuChoice.Divide:
                        //Divide the numbers
                        result = n1 / n2;
                        Console.WriteLine("Division:" + result);
                        break;
                    case (int)MenuChoice.Exit:
                        Console.WriteLine("Exited...");
                        break;
                    default:
                        Console.WriteLine("invalid choice !!!");
                        break;
                }
            } while (choice != (int)MenuChoice.Exit);

        }
    }
}
