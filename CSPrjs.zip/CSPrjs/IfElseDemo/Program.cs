﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IfElseDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Take input of salary from user and calculate bonus
            //assuming bonus is 10% of salary if salary is above 5000
            //else bonus is 20%
            int salary;
            double bonus;

            Console.Write("Enter salary:");
            salary =int.Parse(Console.ReadLine());

            if(salary>5000)
            {
                bonus = 0.1 * salary;
            }
            else
            {
                bonus = 0.2 * salary;
            }

            Console.WriteLine("Bonus:" + bonus);
        }
    }
}
