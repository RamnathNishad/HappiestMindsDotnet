﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicsCSPrj
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("Hello World Application in C#");w

            int n1, n2, sum;
            Console.WriteLine("Enter n1:");
            //n1 = int.Parse(Console.ReadLine());
            n1=Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter n2:");
            n2=Convert.ToInt32(Console.ReadLine());

            sum = n1 + n2;

            Console.WriteLine("Sum :" + sum);


            //Console.ReadLine();
        }
    }
}
