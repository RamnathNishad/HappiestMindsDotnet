﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SwitchDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //char c = 'A';
            //Console.WriteLine((int)c);

            //switch case demo
            int choice;

            do
            {
                int n1, n2, result;
                Console.Write("Enter n1:");
                n1 = int.Parse(Console.ReadLine());
                Console.Write("Enter n2:");
                n2 = int.Parse(Console.ReadLine());


                Console.WriteLine("1.Add");
                Console.WriteLine("2.Subtract");
                Console.WriteLine("3.Multiply");
                Console.WriteLine("4.Divide");
                Console.WriteLine("0.Exit");

                Console.Write("Enter choice:");
                choice = int.Parse(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        //Add the numbers
                        result = n1 + n2;
                        Console.WriteLine("Sum:" + result);
                        break;
                    case 2:
                        //Subtract the numbers
                        result = n1 - n2;
                        Console.WriteLine("Difference:" + result);
                        break;
                    case 3:
                        //Multiply the numbers
                        result = n1 * n2;
                        Console.WriteLine("Multiplication:" + result);
                        break;
                    case 4:
                        //Divide the numbers
                        result = n1 / n2;
                        Console.WriteLine("Division:" + result);
                        break;
                    case 5:
                        Console.WriteLine("Exited...");
                        break;
                    default:
                        Console.WriteLine("invalid choice !!!");
                        break;
                }
            }while (choice!=5);
        }
    }
}
