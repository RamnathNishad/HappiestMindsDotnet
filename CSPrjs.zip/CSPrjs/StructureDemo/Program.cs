﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StructureDemo
{
    struct Address
    {
        string city;
        string state;
        string country;

        public void Store(string city,string state,string country)
        {
            this.city = city;
            this.state=state;
            this.country = country;
        }
        public string GetDetails()
        {
            string str = $"City:{this.city}\nState:{this.state}\nCountry:{this.country}";
            return str ;
        }
    }


    internal class Program
    {
        static void Main(string[] args)
        {
            Address address = new Address();
            Console.Write("Enter city:");
            string city = Console.ReadLine();
            Console.Write("Enter state:");
            string state = Console.ReadLine();
            Console.Write("Enter country:");
            string country = Console.ReadLine();

            address.Store(city, state, country);

            Console.WriteLine(address.GetDetails());

            Address adr2 = address;
            adr2.Store("Mysore", "Karnataka", "India");

            Console.WriteLine(address.GetDetails());
            Console.WriteLine(adr2.GetDetails());






           
        }
    }
}
