﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ForLoopDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n, p;
            Console.Write("Enter any number:");
            n = int.Parse(Console.ReadLine());

            for (int i = 1; i <= 10; i++)
            {
                p = n * i;
                Console.WriteLine($"{n} x {i} = {p}");
            }
        }
    }
}
