﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArraysDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //SingleDimensionArray();
            //RectangularArrayDemo();
            JaggedArrayDemo();
        }

        static void SingleDimensionArray()
        {
            int[] numbers = new int[] { 100, 200, 300, 400, 500 };
            //OR
            //numbers[0] = 100;
            //numbers[1] = 200;
            //numbers[2] = 300;
            //numbers[3] = 400;
            //numbers[4] = 500;

            for (int i = 0; i < numbers.Length; i++)
            {
                Console.WriteLine(numbers[i]);
            }
        }
        static void RectangularArrayDemo()
        {
            int[,] numbers = new int[,] { 
                                            { 1, 2, 3 }, 
                                            { 10,20,30},
                                            {40,50,60 },
                                            {70,80,90 } 
                                        };


            //OR
            //numbers[0, 0] = 1;numbers[0, 1] = 2; numbers[0,2] = 3;
            //numbers[1, 0] = 10; numbers[1, 1] = 20; numbers[1, 2] = 30;
            //numbers[2, 0] = 100; numbers[2, 1] = 200; numbers[2, 2] = 300;
            //numbers[3, 0] = 1000; numbers[3, 1] = 2000; numbers[3, 2] = 3000;


            for (int i = 0; i < numbers.GetLength(0); i++)
            {
                for (int j = 0; j < numbers.GetLength(1); j++)
                {
                    Console.Write(numbers[i,j] +"\t");
                }
                Console.WriteLine("");
            }

        }

        static void JaggedArrayDemo()
        {
            int[][] numbers = new int[3][] { 
                                            new int[]{10,20,30 },
                                            new int[]{ 10,20,30,40,50},
                                            new int[]{ 10,20}            
            };

            for (int i = 0; i < numbers.GetLength(0); i++)
            {
                for (int j = 0; j < numbers[i].Length; j++)
                {
                    Console.Write(numbers[i][j] + "\t");
                }
                Console.WriteLine("");
            }


        }

    }
}
