﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            IInterestCalculator calc;

            calc = new SimpleInterest();
            Console.WriteLine("Simple Interest:" + calc.CalculateInterest(10000,10,2));

            calc=new CompoundInterest();
            Console.WriteLine("Compound Interest:" + calc.CalculateInterest(10000, 10, 2));

        }
    }

    interface IInterestCalculator
    {
        public void Display()
        {

        }
        double CalculateInterest(double amount, double rate, int years);
    }

    class SimpleInterest : IInterestCalculator
    {
        public double CalculateInterest(double amount, double rate, int years)
        {
            double interest = amount * rate * years * 0.01;
            return interest;
        }
    }

    class CompoundInterest : IInterestCalculator
    {
        public double CalculateInterest(double amount, double rate, int years)
        {
            double interest = amount * Math.Pow((1 + rate * 0.01), years)-amount;
            return interest;
        }
    }
}



interface ITutor
{
    void Teaching();
    void Mentoring();

}

interface ICook
{
    void PreparesSouthIndianDishes();
    void PreparesNorthIndianDishes();

}



class Person : ITutor, ICook
{
    public void Mentoring()
    {
        throw new NotImplementedException();
    }

    public void PreparesNorthIndianDishes()
    {
        throw new NotImplementedException();
    }

    public void PreparesSouthIndianDishes()
    {
        throw new NotImplementedException();
    }

    public void Teaching()
    {
        throw new NotImplementedException();
    }
}


class A
{
    public virtual void M1() { }
}
class B : A
{
    //public new void M1()
    //{

    //}
}
class C : B
{
    public override void M1()
    {
        
    }
}