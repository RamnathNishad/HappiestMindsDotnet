﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PropertiesDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {

            StringBuilder sb = new StringBuilder("");
            sb.AppendLine("Hello , how are you?");
            sb.AppendLine("I am fine , how abt you?");
            sb.AppendLine("What is ur schedule on weekends?");


            Console.WriteLine(sb.ToString());


            string str2 = "Hello,Ram,can u send the files on my id";

            string[] words = str2.Split(' ');
            for (int i = 0; i < words.Length; i++)
            {
                Console.WriteLine(words[i]);
            }

            string joinedStr =string.Join("#", words);
            Console.WriteLine(joinedStr);            
            

            //traditional syntax
            //Employee emp = new Employee();
            //emp.Ecode = 101;
            //emp.Ename = "Ravi";
            //emp.Salary = 1111;
            //emp.Deptid = 201;


            //Object initializer syntax
            Employee emp = new Employee 
            { 
                Ecode = 101, 
                Ename = "Ravi", 
                Salary = 1111, 
                Deptid = 201 
            };

            Console.WriteLine($"{emp.Ecode}\t{emp.Ename}\t{emp.Salary}\t{emp.Deptid}");
        }
    }

    class Employee
    {
        //Auto-implemented properties

        public int Ecode { get; set; }
        public string Ename { get; set; }
        public int Salary { get; set; }
        public int Deptid { get; set; }


        //int ecode;

        //public int Ecode
        //{
        //    get { return ecode; }
        //    set { this.ecode = value; }
        //}



        //public void SetEcode(int ecode)
        //{
        //    this.ecode = ecode;
        //}

        //public int GetEcode()
        //{
        //    return this.ecode;
        //}

    }
}
