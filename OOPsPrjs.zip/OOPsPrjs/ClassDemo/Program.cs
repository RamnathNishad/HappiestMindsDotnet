﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //create instance of the class
            Employee emp= new Employee(101, "Ramnath", 1111, 201);
            Console.WriteLine(emp.GetDetails());

            Employee emp2 = new Employee(102, "Ravi", 2222, 201);
            Console.WriteLine(emp2.GetDetails());
        }
    }

    //Define a class
    class Employee
    {
        int ecode;
        string ename;
        int salary;
        int deptid;

        public  Employee(int ecode,string ename,int salary,int deptid)
        {
            Console.WriteLine("constructor called");
            this.ecode = ecode;
            this.ename = ename;
            this.salary = salary;
            this.deptid = deptid;
        }
        public string GetDetails()
        {
            return $"{ecode}\t{ename}\t{salary}\t{deptid}";
        }

        ~Employee()
        {
            Console.WriteLine("destructor called");
        }
    }
}
