﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StaticPolymorphism
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Demo demo = new Demo();
            Console.WriteLine("Sum:" + demo.Add(100,200));
            Console.WriteLine("Sum:" + demo.Add(100, 200,300));
            Console.WriteLine("Final String :" + demo.Add("Hello", "World"));

        }
    }

    class Demo
    {
        public int Add(int n1,int n2)
        {
            return n1 + n2;
        }
        public int Add(int n1, int n2,int n3)
        {
            return n1 + n2 + n3;
        }
        public string Add(string s1,string s2)
        {
            return s1 + " " + s2;
        }
    }
}
