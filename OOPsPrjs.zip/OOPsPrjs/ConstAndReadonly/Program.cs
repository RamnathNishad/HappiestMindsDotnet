﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConstAndReadonly
{
    internal class Program
    {
        static void Main(string[] args)
        {
        }
    }

    class Test
    {
        const int x=100;
        readonly int y;
        public Test(int y)
        {
            this.y = y;
        }

        public void SetData(int y)
        {
            //this.y = y; //not allowed
        }




    }
}
