﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DateTimeDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //to get the current system and time
            Console.WriteLine("Current date and time:" + DateTime.Now);

            //to create a specific date and time
            DateTime dt = new DateTime(2020, 11, 25,09,30,10);
            Console.WriteLine("Current date and time:" + dt);

            //to display in a particular format
            Console.WriteLine(dt.ToString("dd-MM-yyyy hh:mm:ss"));

            string str = "05-13-2021";

            DateTime dt2 = DateTime.ParseExact(str,"MM-dd-yyyy",null);
            Console.WriteLine(dt2);


            Console.WriteLine("Year:" + dt2.Year);

            Console.WriteLine(dt2.AddDays(2));
            Console.WriteLine(dt2.Subtract(DateTime.Now));
        }
    }
}
