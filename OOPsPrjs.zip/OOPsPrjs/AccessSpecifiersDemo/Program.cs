﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary1;

namespace AccessSpecifiersDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Test obj = new Test();
            
        }
    }

    //class Test
    //{
    //    private int var_priv;
    //    protected int var_pro;
    //    public int var_pub;
    //    internal int var_intrnl;
    //    protected internal int var_pro_inrnl;
    //}

    class Child : Test
    {
        public void Show()
        {
            var_
        }
    }
}
