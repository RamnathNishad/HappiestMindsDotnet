﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AggregationAndComposition
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Sample s = new Sample();
            
            s = null;


            Data d = new Data(10, 20);
            Sample2 s2 = new Sample2(d);

            s2 = null;

        }
    }

    class Data
    {
        int x;
        int y;
        public Data(int x, int y)
        {
            this.x = x;
            this.y = y; 
        }
        public string Display()
        {
            return $"x={x}\ty={y}";
        }
    }

    //Composition
    class Sample
    {
        Data d;
        public Sample()
        {
            d = new Data(10, 20);
        }
    }


    //Aggregation
    class Sample2
    {
        Data d;
        public Sample2(Data d)
        {
            this.d = d;
        }
    }
}


class Cook
{
    //Association
    public void MakeDosa(string dosaBatter,string salt)
    {
        //dose is ready
    }
}