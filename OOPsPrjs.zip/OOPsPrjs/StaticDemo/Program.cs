﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StaticDemo
{
    internal class Program
    {
        static int a;
        static void Main(string[] args)
        {
            Demo d1 = new Demo(10);
            Demo d2 = new Demo(5);

            
        }
    }


    class Demo
    {
        int x;
        static int y;

        public Demo(int x)
        {
            this.x = x;
            //Demo.y = y;
            Console.WriteLine("non-static ctor called");
        }
        static Demo()
        {
            x = 10;
            y = 20;
            Console.WriteLine("static ctor called");
        }
    }
}
