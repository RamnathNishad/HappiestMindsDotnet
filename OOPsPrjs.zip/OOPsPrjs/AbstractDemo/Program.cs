﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Shape sh;       //=new Shape();   invalid

            sh = new Circle();
            sh.Area();
            sh.Perimeter();
            sh.FillColor();

            Console.WriteLine("\n");

            sh = new Square();
            sh.Area();
            sh.Perimeter();
            sh.FillColor();
        }
    }

    abstract class Shape
    {
        public void FillColor()
        {
            Console.WriteLine("FillColor");
        }
        public abstract void Area();
        public abstract void Perimeter();
    }
    class Circle : Shape
    {
        public override void Area()
        {
            //TODO
            Console.WriteLine("Area of Circle");
        }

        public override void Perimeter()
        {
            //TODO
            Console.WriteLine("Perimeter of Circle");
        }
    }
    class Square : Shape
    {
        public override void Area()
        {
            //TODO
            Console.WriteLine("Area of Square");
        }

        public override void Perimeter()
        {
            //TODO
            Console.WriteLine("Perimeter of Square");
        }
    }
}
