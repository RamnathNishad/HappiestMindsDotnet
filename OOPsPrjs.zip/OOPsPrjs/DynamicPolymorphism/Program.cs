﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DynamicPolymorphism
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Parent obj = new Parent();
            obj.Show();

            obj = new Child1();
            obj.Show();

            obj = new Child2();
            obj.Show();
        }
    }
    class Parent
    {
        public virtual void Show()
        {
            Console.WriteLine("Parent-Show");
        }
    }
    class Child1 :Parent
    {
        //public override void Show()
        //{
        //    Console.WriteLine("Child1-Show");
        //}
    }
    class Child2:Parent
    {
        public override void Show()
        {
            Console.WriteLine("Child2-Show");
        }
    }
}
