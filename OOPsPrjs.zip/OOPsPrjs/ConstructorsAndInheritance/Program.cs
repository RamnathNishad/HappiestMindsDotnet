﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConstructorsAndInheritance
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Child c = new Child(100,200);
            Console.WriteLine(c.GetP());
            Console.WriteLine(c.GetC());

        }
    }

    class Parent
    {
        int p;
        public Parent(int p)
        {
            this.p = p;
        }
        public string GetP()
        {
            return $"Parent:P={this.p}";
        }
    }
    class Child : Parent
    {
        int c;
        public Child(int c,int p) : base(p)
        {
                this.c = c;
        }
        public string GetC()
        {
            return $"Child:C={this.c}";
        }
    }
}
