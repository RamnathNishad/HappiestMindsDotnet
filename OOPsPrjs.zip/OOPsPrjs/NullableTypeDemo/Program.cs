﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NullableTypeDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int? x = null;

            x = 10;

            if(x.HasValue)
            {
                Console.WriteLine("x:" + x.Value);
            }
            else
            {
                Console.WriteLine("no value for x");
            }

            Console.WriteLine(x.GetType());
            //OR Nullable<int> y = null;

        }
    }
}
