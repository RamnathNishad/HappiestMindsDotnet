﻿using HappiestMinds.Blr;
using HappiestMinds;
using HappiestMinds.Dli;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NMSPDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
           Account acc=new Account();
            acc.Show();

            Hr hr = new Hr();
            hr.Show();

            Sales sales = new Sales();
            sales.Show();

            Admin admin = new Admin();
        }
    }  
}
    
namespace HappiestMinds
{
    public class Hr
    {
        public void Show()
        {
            Console.WriteLine("HappiestMinds.Hr.Show()");
        }
    }
    namespace Blr
    {
        public class Account
        {
            public void Show()
            {
                Console.WriteLine("HappiestMinds.Blr.Account.Show()");
            }
        }
    }
    namespace Dli
    {
        public class Sales
        {
            public void Show()
            {
                Console.WriteLine("HappiestMinds.Dli.Sales.Show()");
            }
        }
    }
}






