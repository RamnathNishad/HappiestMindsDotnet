﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    class Test
    {
        private int var_priv;
        protected int var_pro;
        public int var_pub;
        internal int var_intrnl;
        protected internal int var_pro_inrnl;
    }
}
