﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


using System.IO; //for FileStream

namespace FileOperations
{
    internal class Program
    {
        static void Main(string[] args)
        {
            WriteTextFile();
        }
        static void WriteTextFile()
        {
            FileStream fs = null;

            fs = new FileStream(@"F:\RamDellLapData\Vendors\NIIT\Happiest Minds\letter.txt",FileMode.Create,FileAccess.Write);
        
            StreamWriter sw=new StreamWriter(fs);

            Console.WriteLine("Enter data(press ENTER to finish):");
            string data = Console.ReadLine();
            while (data != "")
            {
                sw.WriteLine(data);
                data = Console.ReadLine();
            }            
            
            sw.Close();
            fs.Close();

            Console.WriteLine("File created");
        }
    }
}
