﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceDemo2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int choice,ecode;
            string ename, emailid;

            Console.WriteLine("Select type of employee:");
            Console.WriteLine("1.Permanent");
            Console.WriteLine("2.Contractual");
            choice = int.Parse(Console.ReadLine());

            Console.Write("Enter ecode:");
            ecode= int.Parse(Console.ReadLine());
            Console.Write("Enter ename:");
            ename = Console.ReadLine();
            Console.Write("Enter emailid:");
            emailid = Console.ReadLine();

            if(choice == 1)
            {
                //permanent
                Console.Write("Enter salary:");
                int salary = int.Parse(Console.ReadLine());
                Permanent permanent = new Permanent(ecode, ename, emailid, salary);
                Console.WriteLine(permanent.GetDetails());
            }
            else
            {
                //contractual
                Contractual contractual = new Contractual(ecode, ename, emailid);
                Console.WriteLine(contractual.GetDetails());
            }





        }
    }

    class Employee
    {
        int ecode;
        string ename;
        string emailid;
        public Employee(int ecode, string ename, string emailid)
        {
            this.ecode = ecode;
            this.ename = ename;
            this.emailid = emailid;
        }
        protected string GetEmpDetails()
        {
            return $"{this.ecode}\t{this.ename}\t{this.emailid}";
        }
    }

    class Permanent : Employee
    {
        int salary;
        public Permanent(int ecode, string ename, string emailid,int salary)
            :base(ecode, ename, emailid)
        {
            this.salary = salary;
        }
        public string GetDetails()
        {
            return $"{GetEmpDetails()}\t{this.salary}\t{GetTotalSalary()}";
        }

        double GetTotalSalary()
        {
            double total = 0;
          
            total = salary * 12;
            double bonus=0.1*total;

            total += bonus;

            return total;
        }
    }

    class Contractual : Employee
    {
        int amount = 50000;
        public Contractual(int ecode,string ename,string emailid)
            :base(ecode,ename,emailid)
        {
            
        }
        public string GetDetails()
        {
            return $"{GetEmpDetails()}\t{amount * 12}";
        }
    }
}
