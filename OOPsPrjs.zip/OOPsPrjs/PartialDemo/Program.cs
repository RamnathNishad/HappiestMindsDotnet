﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PartialDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            MyApp app = new MyApp();
            app.DoTask1();
            app.DoTask2();
            app.DoTask3();
            app.DoTask4();
        }
    }

    partial class MyApp
    {
        public void DoTask1() { }
        public void DoTask2() { }

    }

    partial class MyApp
    {
        public void DoTask3() { }
        public void DoTask4() { }
    }
}
