﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConvertVsParseVsTryParse
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int x = 100;
            double d;

            string s = null;// "100.25ffhasa";

            d=Convert.ToDouble(s);
            Console.WriteLine("d:" + d);



            //string s2 = null;// "100gjhjh";
            //int i = int.Parse(s2);

            string s3 = null;// "100jjjh";
            int j;
            if(int.TryParse(s3,out j))
            {
                Console.WriteLine("j=" + j);
            }
            else
            {
                Console.WriteLine("Failed:J=" + j); 
            }

        }
    }
}
