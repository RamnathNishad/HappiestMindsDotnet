﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OutAndRef
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int a = 100;
            Console.WriteLine("Before:a="+a);
            SendData(ref a);
            Console.WriteLine("After:a=" + a);


            int salary=4000;
            double bonus=0;
            CalculateBonus(salary,out bonus);
            Console.WriteLine("\nSalary:{0}\tBonus:{1}",salary,bonus);



            int[] numbers = new int[] { 1, 2, 3, 4, 5 };
            UpdateArray(numbers);
            for (int i = 0; i < numbers.Length; i++)
            {
                Console.WriteLine(numbers[i]);
            }

        }

        static void CalculateBonus(int salary,out double bonus)
        {
            if(salary>5000)
            {
                bonus = 0.1 * salary;
            }
            else
            {
                bonus = 0.2 * salary;
            }
        }
        static void SendData(ref int x)
        {
            x++;
            Console.WriteLine("Inside the method:X="+x);
        }


        static void UpdateArray(int[] numbers)
        {
            for(int i = 0; i < numbers.Length; i++)
            {
                numbers[i] = numbers[i] * numbers[i];
            }
        }
    }
}
